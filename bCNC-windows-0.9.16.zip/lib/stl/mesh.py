from . import stl


class Mesh(stl.BaseStl):
    pass
