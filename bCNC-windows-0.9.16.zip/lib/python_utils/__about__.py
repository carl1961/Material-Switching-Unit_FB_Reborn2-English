__package_name__ = "python-utils"
__version__ = "2.3.0"
__author__ = "Rick van Hattem"
__author_email__ = "Wolph@wol.ph"
__description__ = (
    "Python Utils is a module with some convenient utilities not included "
    "with the standard Python install"
)
__url__ = "https://github.com/WoLpH/python-utils"
